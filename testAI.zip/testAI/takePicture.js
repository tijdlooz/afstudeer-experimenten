const captureBtn = document.getElementById("capture-btn");
const canvas = document.getElementById("canvas");
const naamInput = document.getElementById("naamInput");
const context = canvas.getContext("2d");

captureBtn.addEventListener("click", () => {
        navigator.mediaDevices.getUserMedia({ video: true, audio: false }).then((stream) => {
            const video = document.createElement("video");
            video.srcObject = stream;
            video.onloadedmetadata = () => {
              video.play();
              canvas.width = video.videoWidth;
              canvas.height = video.videoHeight;
              context.drawImage(video, 0, 0, canvas.width, canvas.height);
              const dataURL = canvas.toDataURL();
              download("C:\Users\sem_w\Desktop\testAI", naamInput.value + ".png");
              video.pause();
              stream.getTracks().forEach((track) => {
                track.stop();
              });
            };
          })
          .catch((error) => {
            console.error(error);
          });
      });

      function download(dataURL, filename) {
        const a = document.createElement("a");
        a.href = dataURL;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }