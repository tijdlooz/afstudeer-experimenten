const asciiArt = document.getElementById('ascii-art');
const video = document.getElementById('video');

// Define the characters to use for the ASCII art
const characters = ['S', 'E', 'M', 'W', 'E', 'R', 'K', 'I', 'C', 'O', 'L'];

   // Set the resolution of the ASCII art
const asciiWidth = 120;
const asciiHeight = 40;

// Convert a pixel value to an ASCII character
function pixelToChar(pixel) {
  // Convert the RGB values to grayscale using the formula (r + g + b) / 3
  const grayscale = (pixel[0] + pixel[1] + pixel[2]) / 3;
  // Convert the grayscale value to an index into the characters array
  const index = Math.floor(grayscale / 25.5);
  // Return the corresponding character
  return characters[index];
}

// Convert the video stream to ASCII art
function convertToAscii() {
  // Create a canvas to draw the video stream onto
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0);

        // Calculate the size of each ASCII art "pixel"
  const asciiPixelWidth = canvas.width / asciiWidth;
  const asciiPixelHeight = canvas.height / asciiHeight;
  
  // Get the image data from the canvas
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  const width = imageData.width;
  const height = imageData.height;
  
  // Convert each group of pixels to an ASCII character and build up the ASCII art string
  let ascii = '';
  for (let y = 0; y < asciiHeight; y++) {
    for (let x = 0; x < asciiWidth; x++) {
      // Get the average color of the group of pixels corresponding to the current ASCII "pixel"
      let sumR = 0;
      let sumG = 0;
      let sumB = 0;
      let count = 0;
      for (let dy = 0; dy < asciiPixelHeight; dy++) {
        for (let dx = 0; dx < asciiPixelWidth; dx++) {
          const sx = Math.floor(x * asciiPixelWidth + dx);
          const sy = Math.floor(y * asciiPixelHeight + dy);
          if (sx < width && sy < height) {
            const i = (sy * width + sx) * 4;
            sumR += data[i];
            sumG += data[i + 1];
            sumB += data[i + 2];
            count++;
          }
        }
      }
      const averageR = sumR / count;
      const averageG = sumG / count;
      const averageB = sumB / count;
      
      // Convert the average color to an ASCII character and add it to the string
      ascii += pixelToChar([averageR, averageG, averageB]);
    }
    ascii += '\n';
  }
  
  // Set the ASCII art string in the pre element
  asciiArt.textContent = ascii;
  
  // Call the function again to create an animation loop
  requestAnimationFrame(convertToAscii);
}

// Access the user's webcam
navigator.mediaDevices.getUserMedia({ video: true })
  .then(function(stream) {
    video.srcObject = stream;
    video.play();
    
    // Start the animation loop after a short delay to allow the video stream to initialize
    // setTimeout(convertToAscii, 1000);
  })
  .catch(function(err) {
    console.log('Error accessing webcam:', err);
  });