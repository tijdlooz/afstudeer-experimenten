const asciiArt = document.getElementById('ascii-art');
const video = document.getElementById('video')

var ageGotten = false;

// Define the characters to use for the ASCII art
const characters = ['S', 'E', 'M', 'W', 'E', 'R', 'K', 'I', 'C', 'O', 'L'];

   // Set the resolution of the ASCII art
const asciiWidth = 120;
const asciiHeight = 40;

// Convert a pixel value to an ASCII character
function pixelToChar(pixel) {
    // Convert the RGB values to grayscale using the formula (r + g + b) / 3
    const grayscale = (pixel[0] + pixel[1] + pixel[2]) / 3;
    // Convert the grayscale value to an index into the characters array
    const index = Math.floor(grayscale / 25.5);
    // Return the corresponding character
    return characters[index];
}

function convertToAscii() {
    // Create a canvas to draw the video stream onto
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
  
          // Calculate the size of each ASCII art "pixel"
    const asciiPixelWidth = canvas.width / asciiWidth;
    const asciiPixelHeight = canvas.height / asciiHeight;
    
    // Get the image data from the canvas
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    const width = imageData.width;
    const height = imageData.height;
    
    // Convert each group of pixels to an ASCII character and build up the ASCII art string
    let ascii = '';
    for (let y = 0; y < asciiHeight; y++) {
      for (let x = 0; x < asciiWidth; x++) {
        // Get the average color of the group of pixels corresponding to the current ASCII "pixel"
        let sumR = 0;
        let sumG = 0;
        let sumB = 0;
        let count = 0;
        for (let dy = 0; dy < asciiPixelHeight; dy++) {
          for (let dx = 0; dx < asciiPixelWidth; dx++) {
            const sx = Math.floor(x * asciiPixelWidth + dx);
            const sy = Math.floor(y * asciiPixelHeight + dy);
            if (sx < width && sy < height) {
              const i = (sy * width + sx) * 4;
              sumR += data[i];
              sumG += data[i + 1];
              sumB += data[i + 2];
              count++;
            }
          }
        }
        const averageR = sumR / count;
        const averageG = sumG / count;
        const averageB = sumB / count;
        
        // Convert the average color to an ASCII character and add it to the string
        ascii += pixelToChar([averageR, averageG, averageB]);
      }
      ascii += '\n';
    }
    
    // Set the ASCII art string in the pre element
    asciiArt.textContent = ascii;
    
    // Call the function again to create an animation loop
    requestAnimationFrame(convertToAscii);
}

Promise.all([
    faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
    faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
    faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
    faceapi.nets.ageGenderNet.loadFromUri('/models'),
    faceapi.nets.faceExpressionNet.loadFromUri('/models'),
]). then(startVideo)

function startVideo(){
    navigator.getUserMedia(
        {video: {}},
        stream => video.srcObject = stream,
        err => console.error(err)
    )
}

video.addEventListener('play', () => {
    const canvas = faceapi.createCanvasFromMedia(video);
    //document.body.append(canvas);
    const displaySize = {width: video.width, height: video.height}
    setInterval(async () => {
        const detections = await faceapi.detectAllFaces(video,
            new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceExpressions().withAgeAndGender()
            const resizedDetections = faceapi.resizeResults
            (detections, displaySize)
            canvas.getContext('2d').clearRect(0,0, canvas.width, canvas.height)
            faceapi.draw.drawDetections(canvas, resizedDetections)
            faceapi.draw.drawFaceLandmarks(canvas, resizedDetections)
            faceapi.draw.drawFaceExpressions(canvas, resizedDetections)
            if(ageGotten == false){
            resizedDetections.forEach( detection => {
                const box = detection.detection.box
                const drawBox = new faceapi.draw.DrawBox(box, { label: Math.round(detection.age) + " year old " + detection.gender })
                drawBox.draw(canvas)
                // console.log(Math.round(detection.age));
                // console.log(detection.gender);
                // console.log(detection.expressions.neutral);
                console.log(detection.expressions.angry);
                console.log(detection.expressions.disgusted);
                console.log(detection.expressions.fearful);
                console.log(detection.expressions.happy);
                console.log(detection.expressions.neutral);
                console.log(detection.expressions.sad);
                console.log(detection.expressions.surprised);

                document.getElementById("emotie").innerHTML = detection.expressions.happy.toFixed(2);
                document.getElementById("gender").innerHTML = detection.gender;
                document.getElementById("age").innerHTML = Math.round(detection.age); 
                //ageGotten = true;
              })
            }
    }, 100)
})

// Access the user's webcam
navigator.mediaDevices.getUserMedia({ video: true })
  .then(function(stream) {
    video.srcObject = stream;
    video.play();
    
    // Start the animation loop after a short delay to allow the video stream to initialize
    setTimeout(convertToAscii, 1000);
  })
  .catch(function(err) {
    console.log('Error accessing webcam:', err);
  });