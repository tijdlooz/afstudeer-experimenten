import cv2
import os
import face_recognition
import time

def stiekemFotoMaken():
    # Start the webcam
    video_capture = cv2.VideoCapture(0)

    # Prompt the user to enter their name
    name = input('Enter your name: ')

    # Capture an image from the webcam
    ret, frame = video_capture.read()

    # Save the image with the user's name
    filename = os.path.join("known_faces/" + name + '.png')
    cv2.imwrite(filename, frame)

    # Release the webcam
    video_capture.release()

def testPrint():
    print("ben nu door naar de volgende functie")

stiekemFotoMaken()

time.sleep(3)

testPrint()

# Load the known faces from the known_faces folder
known_faces = []
known_face_names = []

for file in os.listdir('known_faces'):
    image = face_recognition.load_image_file(os.path.join('known_faces', file))
    face_encoding = face_recognition.face_encodings(image)[0]
    known_faces.append(face_encoding)
    known_face_names.append(os.path.splitext(file)[0])

# Start the webcam capture

video_capture = cv2.VideoCapture(0)
video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

while True:
    # Capture a frame from the webcam
    ret, frame = video_capture.read()

    # Find all the faces and face encodings in the frame
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)

    # Loop through each face in this frame
    for face_encoding, face_location in zip(face_encodings, face_locations):
        # See if the face matches any of the known faces
        matches = face_recognition.compare_faces(known_faces, face_encoding)

        # If there was a match, display the name of the person
        if True in matches:
            match_index = matches.index(True)
            name = known_face_names[match_index]
            top, right, bottom, left = face_location
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Display the resulting image
    cv2.imshow('Video', frame)

    # Exit the loop if the user presses the 'q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close the window
video_capture.release()
cv2.destroyAllWindows()
