import cv2
import face_recognition
import os
from gtts import gTTS
from playsound import playsound
import time
import os

# Load the known faces from the known_faces folder
known_faces = []
known_face_names = []
language = 'nl'
speed = 1

text = "hallo Sem"
# Create a gTTS object and save the speech as an MP3 file
tts = gTTS(text=text, lang=language, slow=False)
tts.save("output.mp3")

for file in os.listdir('known_faces'):
    image = face_recognition.load_image_file(os.path.join('known_faces', file))
    face_encoding = face_recognition.face_encodings(image)[0]
    known_faces.append(face_encoding)
    known_face_names.append(os.path.splitext(file)[0])

# Start the webcam capture
video_capture = cv2.VideoCapture(0)

while True:
    # Capture a frame from the webcam
    ret, frame = video_capture.read()

    # Find all the faces and face encodings in the frame
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)

    # Loop through each face in this frame
    for face_encoding, face_location in zip(face_encodings, face_locations):
        # See if the face matches any of the known faces
        matches = face_recognition.compare_faces(known_faces, face_encoding)

        # If there was a match, display the name of the person
        if True in matches:
            match_index = matches.index(True)
            name = known_face_names[match_index]
            top, right, bottom, left = face_location
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Display the resulting image
    cv2.imshow('Video', frame)
    playsound("output.mp3")
    # Exit the loop if the user presses the 'q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close the window
video_capture.release()
cv2.destroyAllWindows()
