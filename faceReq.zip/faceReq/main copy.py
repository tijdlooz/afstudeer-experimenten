import cv2


# Load the cascade classifier for face detection
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# Load the known faces and their names
known_faces = {
    'person1': cv2.imread('person1.jpg'),
    'person2': cv2.imread('person2.jpg'),
    'person3': cv2.imread('person3.jpg')
}

# Create the face recognition model
face_recognizer = cv2.face.LBPHFaceRecognizer_create()

# Train the face recognition model with the known faces
faces = []
labels = []
for label, image in known_faces.items():
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces.append(gray)
    labels.append(label)

face_recognizer.train(faces, np.array(labels))

# Start the webcam
video_capture = cv2.VideoCapture(0)

while True:
    # Read a frame from the webcam
    ret, frame = video_capture.read()

    # Convert the frame to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the grayscale frame
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

    # Recognize the faces using the trained face recognition model
    for (x, y, w, h) in faces:
        # Extract the face from the grayscale frame
        face = gray[y:y+h, x:x+w]

        # Resize the face to match the size of the known faces
        face = cv2.resize(face, known_faces['person1'].shape[:2])

        # Recognize the face using the trained face recognition model
        label, confidence = face_recognizer.predict(face)

        # Draw a rectangle around the face and display the name of the recognized person
        if confidence < 100:
            name = label
        else:
            name = 'unknown'
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(frame, name, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

    # Display the resulting image
    cv2.imshow('Video', frame)

    # Exit the loop if the user presses the 'q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close the window
video_capture.release()
cv2.destroyAllWindows()
