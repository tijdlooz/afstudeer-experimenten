# Import the required modules
from gtts import gTTS
from playsound import playsound
import time
import os
index = 0
while True:
# Get the text to be converted to speech from the user
    text = input("Enter the text you want to convert to speech: ")
    
    # Set the language code and the speed of speech
    language = 'nl'
    speed = 1

    # Create a gTTS object and save the speech as an MP3 file
    tts = gTTS(text=text, lang=language, slow=False)
    tts.save("output"+ str(index) + ".mp3")

    time.sleep(.5)
    # Play the saved MP3 file
    playsound("output"+ str(index) + ".mp3")
    index = index + 1
