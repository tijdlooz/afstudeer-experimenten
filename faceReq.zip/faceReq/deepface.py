import cv2
import time
from deepface import DeepFace

# Load the known faces
known_faces = []
known_names = []
for name in os.listdir("known_faces"):
    image_path = os.path.join("known_faces", name)
    face = DeepFace.detectFace(image_path)
    face_embedding = DeepFace.represent(face)
    known_faces.append(face_embedding)
    known_names.append(name.split(".")[0])

# Start the webcam capture
video_capture = cv2.VideoCapture(0)
video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

while True:
    # Capture a frame from the webcam
    ret, frame = video_capture.read()

    # Find all the faces and face encodings in the frame
    faces = DeepFace.detectFace(frame, enforce_detection=False)
    face_encodings = DeepFace.represent(faces)

    # Loop through each face in this frame
    for face_encoding, face in zip(face_encodings, faces):
        # See if the face matches any of the known faces
        distances = DeepFace.findEuclideanDistance(face_encoding, known_faces)
        min_distance = min(distances)
        min_index = distances.index(min_distance)
        name = known_names[min_index]

        # Draw a rectangle and label the face
        (x, y, w, h) = face
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(frame, name, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Display the resulting image
    cv2.imshow('Video', frame)

    # Exit the loop if the user presses the 'q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close the window
video_capture.release()
cv2.destroyAllWindows()
