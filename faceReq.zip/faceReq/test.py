from playsound import playsound

playsound('output.mp3')