import socket
import pytesseract
from PIL import Image

# Define the IP address and port number
HOST = '127.0.0.1'
PORT = 1234

# Create a server socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the IP address and port number
s.bind((HOST, PORT))

# Listen for incoming connections
s.listen()

# Accept a connection
conn, addr = s.accept()
print('Connected by', addr)

# Loop to wait for commands from Python
while True:
    # Wait for a command from Python
    command = conn.recv(1024).decode()
    
    # Check if the command is to send the variables
    if command == 'send_variables':

    # Load the image
        img = Image.open('C:/Users/sem_w/Desktop/Afstuderen V1/eddeAdbot/Ed de Adbot/Assets/screenshot.png')
        # Convert the image to grayscale
        img = img.convert('L')

        # Use PyTesseract to extract the text from the image
        text = pytesseract.image_to_string(img)
        print(text)

        conn.sendall(str(text).encode())
        
    # Check if the command is to exit the loop
    elif command == 'exit':
        break
        
# Close the connection
conn.close()
