
import json
import time

filename = 'C:/Users/sem_w/Desktop/Afstuderen V1/eddeAdbot/Ed de Adbot/Assets/myData.JSON'
previous_data = []

while True:
    with open(filename, 'r') as f:
        new_data = json.load(f)

    # check if the new data is different from the previous data
    if new_data != previous_data:
        # find the items that are added
        added_items = [item for item in new_data['dataList'] if item not in previous_data]

        # print the added items
        for item in added_items:
            print(json.dumps(item, indent=4))

        # update the previous data
        previous_data = new_data

    # wait for 10 seconds before checking for new data
    time.sleep(10)
