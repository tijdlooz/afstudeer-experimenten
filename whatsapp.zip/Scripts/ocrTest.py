import pytesseract
from PIL import Image

# Load the image
img = Image.open('C:/Users/sem_w/Desktop/Python/whatsApp/whatsapp_env/kaartje3.jpg')

# Convert the image to grayscale
img = img.convert('L')

# Use PyTesseract to extract the text from the image
text = pytesseract.image_to_string(img)
print(text)
