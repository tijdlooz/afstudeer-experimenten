import requests

url = "https://api.green-api.com/waInstance{{1101817537}}/sendMessage/{{f4e8bae234154af4be1c2df37700bf7e2fa8ca53dc5349cb8a}}"

payload = {
    "phone_number": "0620370446",
    "message": "Hello, this is a test message sent using the Green API!",
    "media_url": "https://www.example.com/image.jpg",
    "media_caption": "An example image",
    "api_key": "f4e8bae234154af4be1c2df37700bf7e2fa8ca53dc5349cb8a"
}

response = requests.post(url, data=payload)

if response.status_code == 200:
    try:
        response_json = response.json()
        print("Message ID:", response_json["message_id"])
    except ValueError:
        print("Error: Response content is not in valid JSON format.")
else:
    print("Error sending message: ", response.text)
