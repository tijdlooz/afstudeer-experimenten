import pywhatkit
import time
import pyautogui
from pynput.keyboard import Key, Controller

keyboard = Controller()

telefoonNummer = input("Wat is je telefoonnummer?")
imgPath = "Images/Hallo.jpg"
print("thanks voor je nummer! Ik neem zo snel mogelijk contact met je op!")

def send_whatsapp_message(msg: str):
    try:
        # pywhatkit.sendwhats_image(
        #     receiver=telefoonNummer,
        #     img_path= "C:/Users/sem_w/Desktop/Python/whatsApp/whatsapp_env/Images/Hallo.jpg",
        #     caption= "hallo hallo hallo"
        # )
        # time.sleep(5)

        pywhatkit.sendwhatmsg_instantly(
            phone_no=telefoonNummer, 
            message=msg,
            tab_close =False
        )
        time.sleep(5)

        pyautogui.click()
        time.sleep(2)
        keyboard.press(Key.enter)
        keyboard.release(Key.enter)
        print("Message sent!")

    except Exception as e:
        print(str(e))


if __name__ == "__main__":
    send_whatsapp_message(msg="""

____¶¶¶________________________________¶¶¶¶____¶¶
___¶¶__¶¶¶___________________________¶¶¶______¶¶
___¶_____¶¶¶¶______________________¶¶________¶¶
___¶________¶¶¶¶_________________¶¶_________¶¶
__¶¶___________¶¶¶¶_____________¶¶_________¶¶
__¶¶______________¶¶¶¶¶¶_______¶__________¶¶
__¶¶___________________¶¶¶___¶¶__________¶¶
___¶_____________________¶¶__¶______¶¶¶¶¶¶¶
___¶¶____________________¶¶_¶_____¶¶____ö_¶¶¶
____¶¶_____________________¶¶¶¶¶¶¶_________¶¶¶¶
______¶¶_________________________________¶¶¶
_______¶¶¶______________________________¶¶
__________¶¶¶¶_________________________¶¶
______________¶¶______________________¶¶
_______________¶¶¶¶¶¶________________¶¶
_¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶____________________¶¶
__¶______________________________¶¶¶¶
___¶¶________________________¶¶¶¶¶
____¶¶_______________¶¶¶¶¶¶¶¶¶
______¶¶¶¶_____________¶¶
_________¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶

""")